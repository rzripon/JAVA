package ClassFiles;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class Faculty extends JFrame implements ActionListener

{
   
	JButton b=new JButton("Search");
	JButton b2=new JButton("Logout");
	JButton b3=new JButton("Add Grade");
	JButton b4=new JButton("Notice");
	JLabel l=new JLabel("Faculty Homepage");
	
	public void actionPerformed(ActionEvent a)
	{
		if(a.getSource()==b)
		{
			FacultySearchStudent s=new FacultySearchStudent();
		}
		else if(a.getSource()==b3)
		{
			AddGrade r=new AddGrade();
		}
		else if(a.getSource()==b4)
		{
			Notice p=new Notice();
		}
		else
		{
			Login l=new Login();
		}
		
		this.setVisible(false);
		
	}
	
	
	public Faculty()
	{
		setTitle("FACULTY");  //Title of the frame
		setSize(500,500);   //frame
		setVisible(true);   //visible command for frame
		setLocationRelativeTo(null); //Frame to the center
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window
		this.setContentPane(new JLabel(new ImageIcon("../images/fc.jpg")));
		setResizable(false);
		
		
		l.setBounds(200,35,200,40);    //label  Welcome
		l.setForeground(Color.WHITE);
		add(l);
		
		
		b.setBounds(180,100,140,45);        //for button 1
		add(b);                  
        b.addActionListener(this);

		
		b4.setBounds(80,320,150,35);        //for button 2
		add(b4);
		b4.addActionListener(this);
		
		
		b3.setBounds(300,320,150,35);        //for button 2
		add(b3);
		b3.addActionListener(this);
		
		
		b2.setBounds(205,400,90,30);        //for button 2
		add(b2);
		b2.addActionListener(this);
		
		setLayout(null);
		
		
		
	}
}