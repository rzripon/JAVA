package ClassFiles;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;

 class SearchFaculty extends JFrame implements ActionListener{
    JLabel JL_fname,JL_lname,JL_password,JL_id,JL_gender,JL_religion,JL_dob,JL_blood,JL_dept,JL_Designation,JL_address,JL_contact,JL_email;
    JTextField JT_fname,JT_lname,JT_password,JT_id,JT_gender,JT_religion,JT_dob,JT_blood,JT_dept,JT_designation,JT_address,JT_contact,JT_email;
    JButton btn_search;
    JButton btn_home;
    JButton btn_update;
    JButton btn_delete;
    JButton btn_clr;

      public SearchFaculty(){
          setTitle("Faculty Information");
		  setSize(630,780);
		  setVisible(true);
		  setLocationRelativeTo(null);
		  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  this.setContentPane(new JLabel(new ImageIcon("../images/display.jpg")));
		  setResizable(false);
		  
		  
          JL_id = new JLabel("Faculty ID:");
          JL_id.setBounds(160,30,150,35);
          JT_id = new JTextField(20);
          JT_id.setBounds(240,30,200, 35);
		  
          JL_fname = new JLabel("First Name: ");
          JL_fname.setBounds(120,100,150,30);
          JT_fname = new JTextField(20);
          JT_fname.setBounds(250,100,200,30);
		  
          JL_lname = new JLabel("Last Name: ");
          JL_lname.setBounds(120,140,150,30);
          JT_lname = new JTextField(20);
          JT_lname.setBounds(250,140,200,30);
		  
          JL_password = new JLabel("Password: ");
          JL_password.setBounds(120,180,150,30);
          JT_password = new JTextField(20);
          JT_password.setBounds(250,180,200,30);
		  
		  
		  JL_gender = new JLabel("Gender: ");
          JL_gender.setBounds(120,220,150,30);
          JT_gender = new JTextField(20);
          JT_gender.setBounds(250,220,200,30);
		  
		  
		  JL_religion = new JLabel("Religion: ");
          JL_religion.setBounds(120,260,150,30);
          JT_religion = new JTextField(20);
          JT_religion.setBounds(250,260,200,30);
		  
		  
		  JL_dob = new JLabel("Date of Birth: ");
          JL_dob.setBounds(120,300,150,30);
          JT_dob = new JTextField(20);
          JT_dob.setBounds(250,300,200,30);
		  
		  
		  JL_blood = new JLabel("Blood Group: ");
          JL_blood.setBounds(120,340,150,30);
          JT_blood = new JTextField(20);
          JT_blood.setBounds(250,340,200,30);
		  
		  
		  JL_dept = new JLabel("Department Name: ");
          JL_dept.setBounds(120,380,150,30);
          JT_dept = new JTextField(20);
          JT_dept.setBounds(250,380,200,30);
		  
		  JL_Designation = new JLabel("Designation: ");
          JL_Designation.setBounds(120,420,150,30);
          JT_designation = new JTextField(20);
          JT_designation.setBounds(250,420,200,30);
		  
		  JL_address = new JLabel("Address: ");
          JL_address.setBounds(120,460,150,30);
          JT_address = new JTextField(20);
          JT_address.setBounds(250,460,200,30);
		  
	
		  JL_contact = new JLabel("Contact No.: ");
          JL_contact.setBounds(120,500,150,30);
          JT_contact = new JTextField(20);
          JT_contact.setBounds(250,500,200,30);
		  
		  JL_email = new JLabel("Email: ");
          JL_email.setBounds(120,540,150,30);
          JT_email = new JTextField(20);
          JT_email.setBounds(250,540,200,30);
		  
		  
		  btn_search = new JButton("");
          btn_search.setBounds(450,23,80,45);
          btn_search.addActionListener(this);
		  ImageIcon img2 = new ImageIcon("../images/sr.png");
          btn_search.setIcon(img2);
		  
		  btn_update = new JButton("Update");
          btn_update.setBounds(270,620,100,40);
          btn_update.addActionListener(this);
		  
		  btn_delete = new JButton("Delete");
          btn_delete.setBounds(400,680,100,40);
          btn_delete.addActionListener(this);
		  
		  btn_home = new JButton("Home");
          btn_home.setBounds(150,680,100,40);
          btn_home.addActionListener(this);
		  
		  
		  btn_clr = new JButton("");
          btn_clr.setBounds(500,300,50,45);
          btn_clr.addActionListener(this);
		  ImageIcon img = new ImageIcon("../images/clr.png");
          btn_clr.setIcon(img);
		  
		  
		  
          setLayout(null);
          add(btn_search);
          add(btn_delete);
          add(btn_update);
          add(btn_home);
          add(JL_fname);
          add(JT_fname);
          add(JL_lname);
          add(JT_lname);
          add(JL_password);
          add(JT_password);
          add(JL_id);
          add(JT_id);
          add(JL_blood);
          add(JT_blood);
          add(JL_contact);
          add(JT_contact);
          add(JL_Designation);
          add(JT_designation);
          add(JL_gender);
          add(JT_gender);
          add(JL_dept);
          add(JT_dept);
          add(JL_address);
          add(JT_address);
          add(JL_email);
          add(JT_email);
          add(JL_religion);
          add(JT_religion);
          add(JL_dob);
          add(JT_dob);
          add(btn_clr);
		  
    }
	
        

         public void actionPerformed(ActionEvent e) 
		 {
			 if(e.getSource()==btn_update)
			 {
				try
				{
         
					theQuery("update add_faculty set firstname = '"+JT_fname.getText()+"',lastname = '"+JT_lname.getText()+"', password = '"+JT_password.getText()+"',contactno = '"+JT_contact.getText()+"',email = '"+JT_email.getText()+"',bloodgroup = '"+JT_blood.getText()+"',dateofbirth = '"+JT_dob.getText()+"',departmentname = '"+JT_dept.getText()+"',designation = '"+JT_designation.getText()+"',address = '"+JT_address.getText()+"',gender = '"+JT_gender.getText()+"',dateofbirth = "+JT_dob.getText()+" where fid = "+JT_id.getText());
				}	
				catch(Exception ex)
				{
					
				}
			 }
			 
			 
			 else if(e.getSource()==btn_delete)
			 {
				 try
				{
          //"DELETE FROM `add_faculty` WHERE `add_faculty`.`fid` = \'12345\'"?
					 theQuery("DELETE FROM `add_faculty` WHERE `add_faculty`.`fid`= "+JT_id.getText());
					 theQuery("DELETE FROM `login` WHERE `login`.`username` = "+JT_id.getText());
				}
				catch(Exception ex)
				{
					
				}
			 }
			 
			 else if(e.getSource()==btn_clr)
			 {
				 JT_address.setText("");
				JT_blood.setText("");
				JT_contact.setText("");
				JT_dept.setText("");
				JT_designation.setText("");
				JT_dob.setText("");
				JT_email.setText("");
				JT_fname.setText("");
				JT_lname.setText("");
				JT_password.setText("");
				JT_id.setText("");
				JT_gender.setText("");
				JT_religion.setText("");
				this.setVisible(true);
			 }
			 
			 else if(e.getSource()==btn_home)
			 {
				 Admin s=new Admin();
				 setVisible(false);
			 }
			 
			 
			 else
			 {
				 
			try{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
				PreparedStatement ps = con.prepareStatement("SELECT * FROM add_faculty WHERE fid="+ JT_id.getText());
				ResultSet rs = ps.executeQuery();
				if(rs.next()){
					JT_fname.setText(rs.getString("firstname"));
					JT_lname.setText(rs.getString("lastname"));
					JT_password.setText(rs.getString("password"));
					JT_gender.setText(rs.getString("gender"));
					JT_religion.setText(rs.getString("religion"));
					JT_dob.setText(rs.getString("dateofbirth"));
					JT_blood.setText(rs.getString("bloodgroup"));
					JT_dept.setText(rs.getString("departmentname"));
					JT_designation.setText(rs.getString("designation"));
					JT_address.setText(rs.getString("address"));
					JT_contact.setText(rs.getString("contactno"));
					JT_email.setText(rs.getString("email"));
				}
				else
					{
						JOptionPane.showMessageDialog(null, "NO DATA FOR THIS ID");
					}
				}
				
			catch(Exception ex)
				{
				   JOptionPane.showMessageDialog(null, ex.getMessage());
				}
			 }
		}
         
   
   //function to execute the update & delete query
  public void theQuery(String query){
      Connection con = null;
      Statement st = null;
      try{
          con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system","root","");
          st = con.createStatement();
          st.executeUpdate(query);
          JOptionPane.showMessageDialog(null,"Query Executed");
      }
	  catch(Exception ex)
	  {
          JOptionPane.showMessageDialog(null,ex.getMessage());
      }
  }
  
  
  
   

 
}