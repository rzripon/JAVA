package ClassFiles;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class Admin extends JFrame implements ActionListener

{
   
	JButton b=new JButton("Search Student");
	JButton b2=new JButton("Add Faculty");
	JButton b4=new JButton("Add Student");
	JButton b3=new JButton("Logout");
	JButton b5=new JButton("Faculty Registration");
	JButton b6=new JButton("Student Registration");
	JButton b7=new JButton("Search Faculty");
	JLabel l=new JLabel("Adminstrator Homepage");
	
	public void actionPerformed(ActionEvent a)
	{
		if(a.getSource()==b)
		{
			Search s=new Search();
		}
		else if(a.getSource()==b4)
		{
			AddInfoStudent ad=new AddInfoStudent();
		}
		
		else if(a.getSource()==b2)
		{
			AddInfo ad=new AddInfo();
		}
		
		else if(a.getSource()==b5)
		{
			RegistrationFaculty r=new RegistrationFaculty();
		}
		
		else if(a.getSource()==b7)
		{
			SearchFaculty r=new SearchFaculty();
		}
		else if(a.getSource()==b6)
		{
			RegistrationStudent sr=new RegistrationStudent();
		}
		else
		{
			Login l=new Login();
		}
		
		this.setVisible(false);
	}
	
	
	public Admin()
	{
		setTitle("ADMINSTRATOR");  //Title of the frame
		setSize(500,520);   //frame
		setVisible(true);   //visible command for frame
		setLocationRelativeTo(null); //Frame to the center
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window
		this.setContentPane(new JLabel(new ImageIcon("../images/admin2.png")));
		setResizable(false);
		
		
		l.setBounds(180,25,200,40);    //label  Welcome
		l.setForeground(Color.WHITE);
		add(l);
		
		b.setBounds(300,100,140,45);        //for button 1
		add(b);                  
        b.addActionListener(this);
		
		b7.setBounds(60,100,140,45);        //for button 7
		add(b7);                  
        b7.addActionListener(this);
		
		
		b5.setBounds(60,330,150,35);        //for button 5
		add(b5);                  
        b5.addActionListener(this);
		
		
		b2.setBounds(60,280,150,35);        //for button 2
		add(b2);                  
        b2.addActionListener(this);
      
		
		b6.setBounds(280,330,150,35);        //for button 6
		add(b6);
		b6.addActionListener(this);
		
		
		b4.setBounds(280,280,150,35);        //for button 3
		add(b4);
		b4.addActionListener(this);
		
		
		b3.setBounds(205,420,90,30);        //for button Logout
		add(b3);
		b3.addActionListener(this);
		
		setLayout(null);
		
		
		
	}
}