package ClassFiles;
import javax.swing.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;

 class Search extends JFrame implements ActionListener{
    JLabel JL_fname,JL_lname,JL_password,JL_id,JL_gender,JL_religion,JL_dob,JL_blood,JL_dept,JL_programe,JL_credit,JL_cgpa,JL_guardian,JL_contact,JL_email;
    JTextField JT_fname,JT_lname,JT_password,JT_id,JT_gender,JT_religion,JT_dob,JT_blood,JT_dept,JT_programe,JT_credit,JT_cgpa,JT_guardian,JT_contact,JT_email;
    JButton btn_search;
    JButton btn_home;
    JButton btn_update;
    JButton btn_delete;
	JButton btn_clr;

      public Search(){
          setTitle("Student Information");
		  setSize(630,785);
		  setVisible(true);
		  setLocationRelativeTo(null);
		  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  this.setContentPane(new JLabel(new ImageIcon("../images/display.jpg")));
		  setResizable(false);
		  
		  
          JL_id = new JLabel("Student ID:");
          JL_id.setBounds(160,20,150,35);
          JT_id = new JTextField(20);
          JT_id.setBounds(240,20,200, 35);
		  
          JL_fname = new JLabel("First Name: ");
          JL_fname.setBounds(120,90,150,30);
          JT_fname = new JTextField(20);
          JT_fname.setBounds(250,90,200,30);
		  
          JL_lname = new JLabel("Last Name: ");
          JL_lname.setBounds(120,130,150,30);
          JT_lname = new JTextField(20);
          JT_lname.setBounds(250,130,200,30);
		  
          JL_password = new JLabel("Password: ");
          JL_password.setBounds(120,170,150,30);
          JT_password = new JTextField(20);
          JT_password.setBounds(250,170,200,30);
		  
		  
		  JL_gender = new JLabel("Gender: ");
          JL_gender.setBounds(120,210,150,30);
          JT_gender = new JTextField(20);
          JT_gender.setBounds(250,210,200,30);
		  
		  
		  JL_religion = new JLabel("Religion: ");
          JL_religion.setBounds(120,250,150,30);
          JT_religion = new JTextField(20);
          JT_religion.setBounds(250,250,200,30);
		  
		  
		  JL_dob = new JLabel("Date of Birth: ");
          JL_dob.setBounds(120,290,150,30);
          JT_dob = new JTextField(20);
          JT_dob.setBounds(250,290,200,30);
		  
		  
		  JL_blood = new JLabel("Blood Group: ");
          JL_blood.setBounds(120,330,150,30);
          JT_blood = new JTextField(20);
          JT_blood.setBounds(250,330,200,30);
		  
		  
		  JL_dept = new JLabel("Department Name: ");
          JL_dept.setBounds(120,370,150,30);
          JT_dept = new JTextField(20);
          JT_dept.setBounds(250,370,200,30);
		  
		  JL_programe = new JLabel("Programe: ");
          JL_programe.setBounds(120,410,150,30);
          JT_programe = new JTextField(20);
          JT_programe.setBounds(250,410,200,30);
		  
		  JL_credit = new JLabel("Credit Completed: ");
          JL_credit.setBounds(120,450,150,30);
          JT_credit = new JTextField(20);
          JT_credit.setBounds(250,450,200,30);
		  
		  JL_cgpa = new JLabel("CGPA: ");
          JL_cgpa.setBounds(120,490,150,30);
          JT_cgpa = new JTextField(20);
          JT_cgpa.setBounds(250,490,200,30);
		  
		  JL_guardian = new JLabel("Guardian No.: ");
          JL_guardian.setBounds(120,530,150,30);
          JT_guardian = new JTextField(20);
          JT_guardian.setBounds(250,530,200,30);
		  
		  JL_contact = new JLabel("Contact No.: ");
          JL_contact.setBounds(120,570,150,30);
          JT_contact = new JTextField(20);
          JT_contact.setBounds(250,570,200,30);
		  
		  JL_email = new JLabel("Email: ");
          JL_email.setBounds(120,610,150,30);
          JT_email = new JTextField(20);
          JT_email.setBounds(250,610,200,30);
		  
		  
		  
		  btn_search = new JButton("");
          btn_search.setBounds(450,16,80,45);
          btn_search.addActionListener(this);
		  ImageIcon img2 = new ImageIcon("../images/sr.png");
          btn_search.setIcon(img2);
		  
		  btn_update = new JButton("Update");
          btn_update.setBounds(270,680,100,40);
          btn_update.addActionListener(this);
		  
		  btn_delete = new JButton("Delete");
          btn_delete.setBounds(400,680,100,40);
          btn_delete.addActionListener(this);
		  
		  btn_home = new JButton("Home");
          btn_home.setBounds(150,680,100,40);
          btn_home.addActionListener(this);
		  
		  btn_clr = new JButton("");
          btn_clr.setBounds(500,300,50,45);
          btn_clr.addActionListener(this);
		  ImageIcon img = new ImageIcon("../images/clr.png");
          btn_clr.setIcon(img);
		  
		  
		  
		  
          setLayout(null);
          add(btn_search);
          add(btn_delete);
          add(btn_update);
          add(btn_home);
          add(JL_fname);
          add(JT_fname);
          add(JL_lname);
          add(JT_lname);
          add(JL_password);
          add(JT_password);
          add(JL_id);
          add(JT_id);
          add(JL_blood);
          add(JT_blood);
          add(JL_cgpa);
          add(JT_cgpa);
          add(JL_contact);
          add(JT_contact);
          add(JL_credit);
          add(JT_credit);
          add(JL_gender);
          add(JT_gender);
          add(JL_guardian);
          add(JT_guardian);
          add(JL_dept);
          add(JT_dept);
          add(JL_programe);
          add(JT_programe);
          add(JL_email);
          add(JT_email);
          add(JL_religion);
          add(JT_religion);
          add(JL_dob);
          add(JT_dob);
		  add(btn_clr);
		  
    }
	
        

         public void actionPerformed(ActionEvent e) 
		 {
			 if(e.getSource()==btn_update)
			 {
				try
				{
         
					theQuery("update add_student set firstname = '"+JT_fname.getText()+"',lastname = '"+JT_lname.getText()+"', password = '"+JT_password.getText()+"',contactno = '"+JT_contact.getText()+"',email = '"+JT_email.getText()+"',bloodgroup = '"+JT_blood.getText()+"',dateofbirth = '"+JT_dob.getText()+"',departmentname = '"+JT_dept.getText()+"',programename = '"+JT_programe.getText()+"',gurdianno = '"+JT_guardian.getText()+"',cgpa = '"+JT_cgpa.getText()+"',creditcompleted = '"+JT_credit.getText()+"',gender = '"+JT_gender.getText()+"',dateofbirth = '"+JT_dob.getText()+"',dateofbirth = "+JT_dob.getText()+" where sid = "+JT_id.getText());
				}	
				catch(Exception ex)
				{
					
				}
			 }
			 
			 
			 else if(e.getSource()==btn_delete)
			 {
				 try
				{
				//DELETE FROM `login` WHERE `login`.`username` = \'123\'"?
					theQuery("DELETE FROM `add_student` WHERE `add_student`.`sid` = "+JT_id.getText());
					theQuery("DELETE FROM `login` WHERE `login`.`username` = "+JT_id.getText());
					
				}
				catch(Exception ex)
				{
					
				}
			 }
			 
			 else if(e.getSource()==btn_clr)
			 {
				 JT_programe.setText("");
				JT_blood.setText("");
				JT_contact.setText("");
				JT_dept.setText("");
				JT_cgpa.setText("");
				JT_credit.setText("");
				JT_guardian.setText("");
				JT_dob.setText("");
				JT_email.setText("");
				JT_fname.setText("");
				JT_lname.setText("");
				JT_password.setText("");
				JT_id.setText("");
				JT_gender.setText("");
				JT_religion.setText("");
				this.setVisible(true);
			 }
			 
			 else if(e.getSource()==btn_home)
			 {
				 Admin s=new Admin();
				 setVisible(false);
			 }
			 
			 
			 else
			 {
				try{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
					PreparedStatement ps = con.prepareStatement("SELECT * FROM add_student WHERE sid="+ JT_id.getText());
					ResultSet rs = ps.executeQuery();
					if(rs.next()){
						JT_fname.setText(rs.getString("firstname"));
						JT_lname.setText(rs.getString("lastname"));
						JT_password.setText(rs.getString("password"));
						JT_gender.setText(rs.getString("gender"));
						JT_religion.setText(rs.getString("religion"));
						JT_dob.setText(rs.getString("dateofbirth"));
						JT_blood.setText(rs.getString("bloodgroup"));
						JT_dept.setText(rs.getString("departmentname"));
						JT_programe.setText(rs.getString("programename"));
						JT_credit.setText(rs.getString("creditcompleted"));
						JT_cgpa.setText(rs.getString("cgpa"));
						JT_guardian.setText(rs.getString("gurdianno"));
						JT_contact.setText(rs.getString("contactno"));
						JT_email.setText(rs.getString("email"));
					}  
				else
					{
						JOptionPane.showMessageDialog(null, "NO DATA FOR THIS ID");
					}
				}
			catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.getMessage());
				}
			 }
		}
   
   
   //function to execute the update & delete query
  public void theQuery(String query){
      Connection con = null;
      Statement st = null;
      try{
          con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system","root","");
          st = con.createStatement();
          st.executeUpdate(query);
          JOptionPane.showMessageDialog(null,"Query Executed");
      }
	  catch(Exception ex)
	  {
          JOptionPane.showMessageDialog(null,ex.getMessage());
      }
  }
  
  

}