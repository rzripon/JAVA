package ClassFiles;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
class Notice extends JFrame implements ActionListener
{
	JLabel cn=new JLabel("Course Name:");
	JLabel cc=new JLabel("Course Sec:");
	
	String [] cnf={"Java","Algorithm","Database","COA","Data Structure","Discrete Math","Computer Network","Operating System"," "};
	JComboBox cnf0=new JComboBox(cnf);
	
	String [] f2={"A","B","C","D"};
	JComboBox f20=new JComboBox(f2);
	
	
	JLabel l=new JLabel("Notice:");
	JTextArea f=new JTextArea();
	
	JButton b=new JButton("Cancel");
	JButton b2=new JButton("Submit");
	
	public void actionPerformed(ActionEvent a)
	{
		if (a.getSource()==b2)
		{
			try{
                  Class.forName("com.mysql.jdbc.Driver");
				  Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
                  PreparedStatement ps = con.prepareStatement("insert into notice(coursename,coursesec,notice) values(?,?,?)");
				  ps.setString(1, cnf0.getSelectedItem().toString());
				  ps.setString(2, f20.getSelectedItem().toString());
				  ps.setString(3, f.getText());
				
				  ps.executeUpdate();
				  
				
				  JOptionPane.showMessageDialog(this,"Successesfully saved");
            }
			
			catch (SQLException ex) 
				{
					JOptionPane.showMessageDialog(this, "wrong input", "Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Error sql");
				}
				
			catch(Exception e)
				{
                  System.out.print("Error");
				}
			
			Faculty d=new Faculty();
		}

		else
		{
			Faculty d=new Faculty();
		}
		
	this.setVisible(false);
	}
	
	public Notice()
	{
		setSize(500,500);   //frame
		setTitle("Notice");  //Title of the frame
		setVisible(true);
		setLocationRelativeTo(null); //Frame to the center
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window	
		this.setContentPane(new JLabel(new ImageIcon("../images/display.jpg")));
		setResizable(false);
		
		cn.setBounds(80,80,100,30);
		add(cn);
		cnf0.setBounds(190,80,140,30);
		add(cnf0);
		
		cc.setBounds(80,120,100,30);
		add(cc);
		f20.setBounds(190,120,50,30);
		add(f20);
		
		l.setBounds(80,200,100,30);    
		add(l); 
		
		f.setEditable(true);
        f.setBounds(160,200,240,110);	
		add(f); 
		
		b.setBounds(70,350,100,30);        //for button 1
		add(b);                  
        b.addActionListener(this);
		
		b2.setBounds(280,350,100,30);        //for button 1
		add(b2);                  
        b2.addActionListener(this);
		setLayout(null);
	}
}