package ClassFiles;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
class ViewGrade extends JFrame implements ActionListener
{
	JLabel cn=new JLabel("Course Name:");
	JLabel cc=new JLabel("ID:");
	
	String [] cnf={"Java","Algorithm","Database","COA","Data Structure","Discrete Math","Computer Network","Operating System"," "};
	JComboBox cnf0=new JComboBox(cnf);
	
	JTextField f20=new JTextField();
	
	
	JLabel l=new JLabel("Grade:");
	JTextField f=new JTextField();
	
	JButton b=new JButton("Home");
	JButton b2=new JButton("Search");
	
	public void actionPerformed(ActionEvent a)
	{
		if (a.getSource()==b2)
		{
				try{
					
					Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
				PreparedStatement ps = con.prepareStatement("SELECT * FROM add_grade WHERE sid='"+ f20.getText() +"' AND coursename=('" + cnf0.getSelectedItem().toString() + "')");
				ResultSet rs = ps.executeQuery();
					if(rs.next())
					{
						f.setText(rs.getString("grade"));
					}  
				else
					{
						JOptionPane.showMessageDialog(null, "NO Grade for THIS Subject");
					}
				}
			catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.getMessage());
				}
		}

		else
		{
			Student d=new Student();
			this.setVisible(false);
		}
		
	
	}

	
   
	
	public ViewGrade()
	{
		setSize(500,500);   //frame
		setTitle("View Grade");  //Title of the frame
		setVisible(true);
		setLocationRelativeTo(null); //Frame to the center
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window	
		this.setContentPane(new JLabel(new ImageIcon("../images/display.jpg")));
		setResizable(false);
		
		
		cn.setBounds(80,80,100,30);
		add(cn);
		cnf0.setBounds(190,80,140,30);
		add(cnf0);
		
		cc.setBounds(80,120,100,30);
		add(cc);
		f20.setBounds(190,120,140,30);
		add(f20);
		
		l.setBounds(80,250,100,30);    
		add(l); 
		
		
        f.setBounds(160,250,100,30);	
		add(f); 
		
		b.setBounds(220,390,100,30);        //for button 1
		add(b);                  
        b.addActionListener(this);
		
		b2.setBounds(220,165,100,30);        //for button 2
		add(b2);                  
        b2.addActionListener(this);
		setLayout(null);
	}
}