package ClassFiles;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class AddInfo extends JFrame implements ActionListener

{
	JButton b=new JButton("Save");
	JButton b2=new JButton("Cancel");
	JTextField f1=new JTextField();
	JTextField f2=new JTextField();
	JTextField f3=new JTextField();
	JTextField f4=new JTextField();
	
	
	JRadioButton f5=new JRadioButton("Male");
	JRadioButton f51=new JRadioButton("Female");
	
	
	String [] rlgn={"Islam","Hindu","Christian","Buddhist","Others"};
	JComboBox f6=new JComboBox(rlgn);
	
	JTextField f7=new JTextField();
	
	String [] bld={"A_Positive","A_Negative","B_Positive","B_Negative","AB_Positive","AB_Negative","O_Positive","O_Negative"};
	JComboBox f8=new JComboBox(bld);
	String [] dpt={"Faculty Of Science & Information Technolgy","Faculty Of Engineering","Faculty Of Business Adminstration","Faculty Of Arts & Social Science"};
	JComboBox f9=new JComboBox(dpt);
	JTextField f10=new JTextField();
	JTextField f11=new JTextField();
	JTextField f12=new JTextField();
	JTextField f13=new JTextField();
	
	JLabel l1=new JLabel("ID:");
	JLabel l2=new JLabel("First Name:");
	JLabel l3=new JLabel("Last Name:");
	JLabel l4=new JLabel("Password:");
	JLabel l5=new JLabel("Gender:");
	JLabel l6=new JLabel("Religion:");
	JLabel l7=new JLabel("Date Of Birth:");
	JLabel l8=new JLabel("Blood Group:");
	JLabel l9=new JLabel("Department Name:");
	JLabel l10=new JLabel("Designation:");
	JLabel l11=new JLabel("Address:");
	JLabel l12=new JLabel("Contact No.:");
	JLabel l13=new JLabel("Email:");
	
	
	
	
	public void actionPerformed(ActionEvent a)
	{
		if (a.getSource()==b)
		{
			try{
                  Class.forName("com.mysql.jdbc.Driver");
				  Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
                  PreparedStatement ps = con.prepareStatement("insert into add_faculty(fid,firstname,lastname,password,gender,religion,dateofbirth,bloodgroup,departmentname,designation,address,contactno,email) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
				  
				  PreparedStatement ps2 = con.prepareStatement("insert into login(username,password,type) values (?,?,?)");
				  ps2.setString(1, f1.getText());
				  ps2.setString(2, f4.getText());
				  ps2.setString(3, "faculty");
				 
				  ps.setString(1, f1.getText());
				  ps.setString(2, f2.getText());
				  ps.setString(3, f3.getText());
				  ps.setString(4, f4.getText());
				  ps.setString(5, f5.getText());
				 
				  ps.setString(6, f6.getSelectedItem().toString());
				  ps.setString(7, f7.getText());
				  
				  ps.setString(8, f8.getSelectedItem().toString());
				  ps.setString(9, f9.getSelectedItem().toString());
				 
				  ps.setString(10, f10.getText());
				  ps.setString(11, f11.getText());
				  ps.setString(12, f12.getText());
				  ps.setString(13, f13.getText());
				  
				  ps.executeUpdate();
				  ps2.executeUpdate(); 
				
					JOptionPane.showMessageDialog(this,"Successesfully saved");
					Admin d=new Admin();	
				
            }
			
			catch (SQLException ex) 
				{
					JOptionPane.showMessageDialog(null,ex.getMessage());
					AddInfo i=new AddInfo();
					System.out.println("Error sql");
				}
				
			catch(Exception e)
				{
                  System.out.print("Error");
				}
			
		}

		else
		{
			Admin d=new Admin();
		}
		
	this.setVisible(false);
	}
	
	
	
	
	public AddInfo()
	{
		setTitle("Add Faculty Information");  //Title of the frame
		setSize(615,710);   
		setVisible(true); 
		setLocationRelativeTo(null); //Frame to the center
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window	
		this.setContentPane(new JLabel(new ImageIcon("../images/background2.jpg")));	
		setResizable(false);
		
		
		l1.setBounds(100,30,150,30); 
		l1.setForeground(Color.WHITE);
		add(l1); 
		
		
        f1.setBounds(250,30,210,30);	
		add(f1); 
	

		
		l2.setBounds(100,70,150,30);
		l2.setForeground(Color.WHITE);		
		add(l2);  		
		
		f2.setBounds(250,70,210,30);   
		add(f2);  
	
	
		
		l3.setBounds(100,110,150,30); 
		l3.setForeground(Color.WHITE);
		add(l3);  		
		
		f3.setBounds(250,110,210,30);   
		add(f3);
		setLayout(null);
		
		
		l4.setBounds(100,150,150,30);
		l4.setForeground(Color.WHITE);
		add(l4);  		
		
		f4.setBounds(250,150,210,30);   
		add(f4);
		
		
		l5.setBounds(100,190,150,30); 
		l5.setForeground(Color.WHITE);
		add(l5);  		
		
		f5.setBounds(250,190,100,30);   
		add(f5);
		f51.setBounds(370,190,100,30);   
		add(f51);
		ButtonGroup bg=new ButtonGroup();
	    bg.add(f5);
	    bg.add(f51);
		
		
		
		l6.setBounds(100,230,150,30); 
		l6.setForeground(Color.WHITE);
		add(l6);  		
		
		f6.setBounds(250,230,210,30);   
		add(f6);
		
		
		
		l7.setBounds(100,270,150,30);
		l7.setForeground(Color.WHITE);
		add(l7);  		
		
		f7.setBounds(250,270,210,30);   
		add(f7);
		
		
		
		l8.setBounds(100,310,150,30); 
		l8.setForeground(Color.WHITE);
		add(l8);  		
		
		f8.setBounds(250,310,210,30);   
		add(f8);
		

		
		l9.setBounds(100,350,150,30);
		l9.setForeground(Color.WHITE);
		add(l9);  		
		
		f9.setBounds(250,350,210,30);   
		add(f9);
		
		
		l10.setBounds(100,390,150,30); 
		l10.setForeground(Color.WHITE);
		add(l10);  		
		
		f10.setBounds(250,390,210,30);   
		add(f10);
		
		
		l11.setBounds(100,430,150,30);
		l11.setForeground(Color.WHITE);
		add(l11);  		
		
		f11.setBounds(250,430,210,30);   
		add(f11);

		
		
		l12.setBounds(100,470,150,30); 
		l12.setForeground(Color.WHITE);
		add(l12);  		
		
		f12.setBounds(250,470,210,30);   
		add(f12);
		
		
		l13.setBounds(100,510,150,30); 
		l13.setForeground(Color.WHITE);
		add(l13);  		
		
		f13.setBounds(250,510,210,30);   
		add(f13);

		
		
		
		b.setBounds(450,600,75,34);        
		add(b); 
		b.addActionListener(this);		
		
		b2.setBounds(100,600,75,34);        
		add(b2);  
		b2.addActionListener(this);
		
		setLayout(null);	
	}
	
}