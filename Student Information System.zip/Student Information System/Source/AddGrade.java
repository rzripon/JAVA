package ClassFiles;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
class AddGrade extends JFrame implements ActionListener

{
   
	JLabel l=new JLabel("Student ID:");
	JTextField f=new JTextField();
	
	JLabel l2=new JLabel("Course Code:");
	JTextField f2=new JTextField();
	
	JLabel l4=new JLabel("Subject Name:");
	String[] sbj = {"Java","Algorithm","Database","COA","Data Structure","Discrete Math","Computer Network","Operating System"," "};
    JComboBox s= new JComboBox(sbj);
	
	JLabel l3=new JLabel("Marks:");
	JTextField f3=new JTextField();

	JLabel l5=new JLabel("Grade:");
	String[] grade = { "A+", "A", "A-","B+","B","B-","C+","C","C-","D+","D","D-"};
    JComboBox c= new JComboBox(grade);
	
	JButton b=new JButton("Submit");
	JButton b2=new JButton("Cancel");
		
	
	
		public void actionPerformed(ActionEvent a)
	{
		if (a.getSource()==b)
		{
			try{
                  Class.forName("com.mysql.jdbc.Driver");
				  Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
                  PreparedStatement ps = con.prepareStatement("insert into add_grade(sid,coursecode,coursename,marks,grade) values(?,?,?,?,?)");
				  ps.setString(1, f.getText());
				  
				  ps.setString(2, f2.getText());
				  ps.setString(3, s.getSelectedItem().toString());
				  ps.setString(4, f3.getText());
				  ps.setString(5, c.getSelectedItem().toString());
				  

				  ps.executeUpdate();
				  
				JOptionPane.showMessageDialog(this,"Successesfully saved");	
				
            }
			
			catch (SQLException ex) 
				{
					System.out.println("Error sql");
				}
				
			catch(Exception e)
				{
                  System.out.print("Error");
				}
			
			Faculty d=new Faculty();
			this.setVisible(false);
		}

		else
		{
			Faculty d=new Faculty();
			this.setVisible(false);
		}
		
	}
		
	
	
	public AddGrade()
	{
		
		setSize(575,400);   //frame
		setTitle("Add Grade");  //Title of the frame
		setVisible(true);
		setLocationRelativeTo(null); //Frame to the center
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window	
		this.setContentPane(new JLabel(new ImageIcon("../images/display.jpg")));	
		setResizable(false);
		
		
		l.setBounds(100,30,150,30);    
		add(l); 
		
		
        f.setBounds(250,30,210,30);	
		add(f); 
	

		
		l2.setBounds(100,70,150,30);   
		add(l2);  		
		
		f2.setBounds(250,70,210,30);   
		add(f2); 
		
		
		l4.setBounds(100,110,150,30); 
		add(l4);
		s.setBounds(250,110,150,30);   
		add(s); 
		
		
		l3.setBounds(100,150,150,30);   
		add(l3);  		
		
		f3.setBounds(250,150,210,30);   
		add(f3); 
		
		
		l5.setBounds(100,190,150,30);
		add(l5);
		c.setBounds(250,190,150,30);   
		add(c); 
		
		b.setBounds(320,300,130,35);        //for button 1
		add(b);                  
        b.addActionListener(this);
		
		b2.setBounds(100,300,130,35);        //for button 1
		add(b2);                  
        b2.addActionListener(this);
		
		setLayout(null);
		
	}
	
}