package ClassFiles;
class LoginMain
{
	public static void main(String[]args)
	{
		Login l=new Login();
	}
}