package ClassFiles;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class Login extends JFrame implements ActionListener

{
    
	JButton b=new JButton("");
	JButton b2=new JButton("");
	JTextField f=new JTextField();
	JPasswordField f2=new JPasswordField();
	JLabel l=new JLabel("Student Information System");
	JLabel l1=new JLabel("User Name:");
	JLabel l2=new JLabel("Password:");
	
	
	
	public void actionPerformed(ActionEvent a)
	{
		if (a.getSource()==b)
		{
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
				PreparedStatement ps = con.prepareStatement("SELECT * FROM login WHERE username='"+ f.getText() +"' AND password=('" + f2.getText() + "')");
				ResultSet result = ps.executeQuery();
             if(result.next())
				{
				  if ("admin".equals(result.getString("type"))) 
					{
						JOptionPane.showMessageDialog(null," Welcome Administrator");
						Admin d=new Admin();
					}
				else if ("faculty".equals(result.getString("type")))
					{
						JOptionPane.showMessageDialog(null," Welcome Sir !");
						Faculty f=new Faculty();
					}
				else 
					{
						JOptionPane.showMessageDialog(null," Welcome Student !");
						Student S=new Student();
					}
						
				}
				
             else
				{
					JOptionPane.showMessageDialog(this, "Wrong username or password", "Error login", JOptionPane.ERROR_MESSAGE);
					Login l=new Login();
				}
			}
			
			catch (SQLException ex) 
				{
					JOptionPane.showMessageDialog(null, ex.getMessage());
					System.out.println("Sql Error");
				}

			catch(Exception eq)
				{
					JOptionPane.showMessageDialog(null, eq.getMessage());
				}
				
			this.setVisible(false);				
		}

		else
		{
           f.setText("");
           f2.setText("");
		   this.setVisible(true);
		}
	}
	
	
	
	public Login()
	{
		setTitle("Welcome To Login");  //Title of the frame
		setSize(500,500);   //frame
		setVisible(true);   //visible command for frame
		setLocationRelativeTo(null); //Frame to the center
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window
		this.setContentPane(new JLabel(new ImageIcon("../images/login.jpg")));
		setResizable(false);
		
		
		
		l.setBounds(120,70,300,40);    //label  login
		add(l); 
		l.setFont(new Font("Courier New",Font.BOLD,17));
		l.setForeground(Color.BLACK);
		
		
		l1.setBounds(60,140,120,30);    //label  1
		add(l1);  
        f.setBounds(180,140,200,30);	//text field 1
		add(f); 
	    setLayout(null);

		
		l2.setBounds(60,210,120,30);   //label  2
		add(l2);  		
		f2.setBounds(180,210,200,30);   //text field 2
		add(f2); 
		setLayout(null);
	
		
		b.setBounds(330,340,75,40);        //for button 1
		add(b);  
		ImageIcon img2 = new ImageIcon("../images/log.png");
        b.setIcon(img2);		
        b.addActionListener(this);
		setLayout(null);
		
	
		b2.setBounds(108,340,75,40);        //for button 2
		add(b2);
		ImageIcon img = new ImageIcon("../images/clr.png");
        b2.setIcon(img);
		b2.addActionListener(this);
		setLayout(null);	
		
	}
	
}