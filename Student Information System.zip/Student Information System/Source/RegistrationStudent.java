package ClassFiles;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class RegistrationStudent extends JFrame implements ActionListener

{
	JButton b=new JButton("Save");
	JButton b2=new JButton("Cancel");
	
	JLabel l=new JLabel("Student ID:");
	JTextField f=new JTextField();
	
	JLabel l2=new JLabel("Course1 Sec:");
	
	JLabel l3=new JLabel("Course2 Sec:");
	
	JLabel l4=new JLabel("Course3 Sec:");
	
	JLabel l5=new JLabel("Course4 Sec:");
	
	
	//Registration
	JLabel reg=new JLabel("Registration");
	JLabel cc=new JLabel("Course Code 1:");
	JLabel cc2=new JLabel("Course Code 2:");
	JLabel cc3=new JLabel("Course Code 3:");
	JLabel cc4=new JLabel("Course Code 4:");
	JLabel cn=new JLabel("Course Name 1:");
	JLabel cn2=new JLabel("Course Name 2:");
	JLabel cn3=new JLabel("Course Name 3:");
	JLabel cn4=new JLabel("Course Name 4:");
	
	JTextField ccf=new JTextField();
	JTextField ccf2=new JTextField();
	JTextField ccf3=new JTextField();
	JTextField ccf4=new JTextField();
	
	String [] f20={"A","B","C","D"};
	JComboBox f200=new JComboBox(f20);
	
	String [] f30={"A","B","C","D"};
	JComboBox f300=new JComboBox(f30);
	
	String [] f40={"A","B","C","D"};
	JComboBox f400=new JComboBox(f40);
	
	String [] f50={"A","B","C","D"};
	JComboBox f500=new JComboBox(f50);
	
	
	
	String [] cnf={"Java","Algorithm","Database","COA","Data Structure","Discrete Math","Computer Network","Operating System"," "};
	JComboBox cnf00=new JComboBox(cnf);
	
	String [] cnf2={"Algorithm","Java","Database","COA","Data Structure","Discrete Math","Computer Network","Operating System"," "};
	JComboBox cnf20=new JComboBox(cnf2);
	
	String [] cnf3={"Database","Java","Algorithm","COA","Data Structure","Discrete Math","Computer Network","Operating System"," "};
	JComboBox cnf30=new JComboBox(cnf3);
	
	String [] cnf4={"Operating System","Java","Algorithm","Database","COA","Data Structure","Discrete Math","Computer Network"," "};
	JComboBox cnf40=new JComboBox(cnf4);
	
	
	
	public void actionPerformed(ActionEvent a)
	{
		if (a.getSource()==b)
		{
			try{
                  Class.forName("com.mysql.jdbc.Driver");
				  Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_information_system", "root", "");
                  PreparedStatement ps = con.prepareStatement("insert into student_registration(sid,coursecode1,coursename1,course1sec,coursecode2,coursename2,course2sec,coursecode3,coursename3,course3sec,coursecode4,coursename4,course4sec) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
				  ps.setString(1, f.getText());
				  
				  ps.setString(2, ccf.getText());
				  ps.setString(3, cnf00.getSelectedItem().toString()); //combo box
				  ps.setString(4, f200.getSelectedItem().toString());
				  
				  
				  ps.setString(5, ccf2.getText());
				  ps.setString(6, cnf20.getSelectedItem().toString());
				  ps.setString(7, f300.getSelectedItem().toString());
				  
				  ps.setString(8, ccf3.getText());
				  ps.setString(9, cnf30.getSelectedItem().toString());
				  ps.setString(10, f400.getSelectedItem().toString());
				  
				  
				  ps.setString(11, ccf4.getText());
				  ps.setString(12, cnf40.getSelectedItem().toString());
				  ps.setString(13, f500.getSelectedItem().toString());
				 
				  
				  ps.executeUpdate(); 
				  
				JOptionPane.showMessageDialog(this,"Successesfully saved");
				Admin d=new Admin();	
				
            }
			
			catch (SQLException ex) 
				{
					System.out.println("Error sql");
				}
				
			catch(Exception e)
				{
                  System.out.print("Error");
				}
			
			Admin d=new Admin();
		}

		else
		{
			Admin d=new Admin();
		}
		
	this.setVisible(false);
	}
	
	
	public RegistrationStudent()
	{
		setTitle("Student Registration");  //Title of the frame
		setSize(975,655);   
		setVisible(true); 
		setLocationRelativeTo(null); //Frame to the center
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window	
		this.setContentPane(new JLabel(new ImageIcon("../images/regi.jpg")));
		setResizable(false);
		
		
		
		
		reg.setBounds(400,30,200,30);
		
		reg.setFont(new Font("Courier New",Font.BOLD,20));
		add(reg);
		
		l.setBounds(90,80,150,30);
		add(l);
		f.setBounds(240,80,180,30);
		add(f);
		
		
		
		l2.setBounds(590,230,150,30);
		add(l2);
		f200.setBounds(740,230,100,30);
		add(f200);
		
		l3.setBounds(590,280,150,30);
		add(l3);
		f300.setBounds(740,280,100,30);
		add(f300);
		
		l4.setBounds(590,330,150,30);
		add(l4);
		f400.setBounds(740,330,100,30);
		add(f400);
		
		l5.setBounds(590,380,150,30);
		add(l5);
		f500.setBounds(740,380,100,30);
		add(f500);
		
		
		
		
		
		
		
		cc.setBounds(90,130,150,30);
		add(cc);
		ccf.setBounds(240,130,180,30);
		add(ccf);
		
		
		cn.setBounds(90,180,150,30);
		add(cn);
		cnf00.setBounds(240,180,180,30);
		add(cnf00);
		
		cc2.setBounds(90,230,150,30);
		add(cc2);
		ccf2.setBounds(240,230,180,30);
		add(ccf2);
		
		cn2.setBounds(90,280,150,30);
		add(cn2);
		cnf20.setBounds(240,280,180,30);
		add(cnf20);
		
		cc3.setBounds(90,330,150,30);
		add(cc3);
		ccf3.setBounds(240,330,180,30);
		add(ccf3);
		
		cn3.setBounds(90,380,150,30);
		add(cn3);
		cnf30.setBounds(240,380,180,30);
		add(cnf30);
		
		cc4.setBounds(90,430,150,30);
		add(cc4);
		ccf4.setBounds(240,430,180,30);
		add(ccf4);
		
		cn4.setBounds(90,480,150,30);
		add(cn4);
		cnf40.setBounds(240,480,180,30);
		add(cnf40);
		
		
		b.setBounds(715,570,75,34);        
		add(b); 
		b.addActionListener(this);		
		
		b2.setBounds(100,570,75,34);        
		add(b2);  
		b2.addActionListener(this);
		
		setLayout(null);	
	}
	
}