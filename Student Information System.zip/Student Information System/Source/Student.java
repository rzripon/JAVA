package ClassFiles;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class Student extends JFrame implements ActionListener

{
   
	JButton b=new JButton("View Grade");
	JButton b2=new JButton("View Notice");
	JButton b3=new JButton("Logout");
	JLabel l=new JLabel("Student Homepage");
	
	public void actionPerformed(ActionEvent a)
	{
		if(a.getSource()==b)
		{
			ViewGrade v=new ViewGrade();
		}

		else if(a.getSource()==b2)
		{
			ViewNotice p=new ViewNotice();
		}
		else
		{
			Login l=new Login();
		}
		
		this.setVisible(false);
		
	}
	
	
	public Student()
	{
		setTitle("Student");  //Title of the frame
		setSize(630,387);   //frame
		setVisible(true);   //visible command for frame
		setLocationRelativeTo(null); //Frame to the center
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //For close the window
		this.setContentPane(new JLabel(new ImageIcon("../images/student.gif")));
		setResizable(false);
		
		
		
		l.setBounds(253,35,200,40);    //label  Welcome
		add(l);
		l.setFont(new Font("Courier New",Font.BOLD,15));
		l.setForeground(Color.WHITE);
		
		b.setBounds(150,100,150,35);        //for button 1
		add(b);                  
        b.addActionListener(this);
		
		b2.setBounds(320,100,150,35);        //for button 2
		add(b2);
		b2.addActionListener(this);
		
		b3.setBounds(220,300,150,35);        //for button 2
		add(b3);
		b3.addActionListener(this);
		
		setLayout(null);
		
		
		
	}
}