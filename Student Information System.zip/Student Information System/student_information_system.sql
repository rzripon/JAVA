-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2016 at 09:38 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_information_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_faculty`
--

CREATE TABLE `add_faculty` (
  `fid` varchar(20) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `password` int(20) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `dateofbirth` varchar(20) NOT NULL,
  `bloodgroup` varchar(20) NOT NULL,
  `departmentname` varchar(50) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` int(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `add_grade`
--

CREATE TABLE `add_grade` (
  `sid` varchar(20) NOT NULL,
  `coursecode` int(15) NOT NULL,
  `coursename` varchar(30) NOT NULL,
  `marks` int(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `add_student`
--

CREATE TABLE `add_student` (
  `sid` varchar(20) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `password` int(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `religion` varchar(15) NOT NULL,
  `dateofbirth` varchar(50) NOT NULL,
  `bloodgroup` varchar(20) NOT NULL,
  `departmentname` varchar(50) NOT NULL,
  `programename` varchar(30) NOT NULL,
  `creditcompleted` int(5) NOT NULL,
  `cgpa` float NOT NULL,
  `gurdianno` int(20) NOT NULL,
  `contactno` int(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_registration`
--

CREATE TABLE `faculty_registration` (
  `fid` varchar(20) NOT NULL,
  `coursecode1` int(15) NOT NULL,
  `coursename1` varchar(20) NOT NULL,
  `course1sec` varchar(5) NOT NULL,
  `coursecode2` int(15) NOT NULL,
  `coursename2` varchar(20) NOT NULL,
  `course2sec` varchar(5) NOT NULL,
  `coursecode3` int(15) NOT NULL,
  `coursename3` varchar(20) NOT NULL,
  `course3sec` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` int(15) NOT NULL,
  `type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `type`) VALUES
('123', 123, 'student'),
('656', 455, 'student'),
('admin', 874766, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `coursename` varchar(50) NOT NULL,
  `coursesec` varchar(10) NOT NULL,
  `notice` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

CREATE TABLE `student_registration` (
  `sid` varchar(20) NOT NULL,
  `coursecode1` int(15) NOT NULL,
  `coursename1` varchar(20) NOT NULL,
  `course1sec` varchar(5) NOT NULL,
  `coursecode2` int(15) NOT NULL,
  `coursename2` varchar(20) NOT NULL,
  `course2sec` varchar(5) NOT NULL,
  `coursecode3` int(15) NOT NULL,
  `coursename3` varchar(20) NOT NULL,
  `course3sec` varchar(5) NOT NULL,
  `coursecode4` int(15) NOT NULL,
  `coursename4` varchar(20) NOT NULL,
  `course4sec` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_faculty`
--
ALTER TABLE `add_faculty`
  ADD PRIMARY KEY (`fid`),
  ADD UNIQUE KEY `id` (`fid`);

--
-- Indexes for table `add_grade`
--
ALTER TABLE `add_grade`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `add_student`
--
ALTER TABLE `add_student`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `id` (`sid`);

--
-- Indexes for table `faculty_registration`
--
ALTER TABLE `faculty_registration`
  ADD UNIQUE KEY `coursecode1` (`coursecode1`),
  ADD UNIQUE KEY `coursecode2` (`coursecode2`),
  ADD UNIQUE KEY `coursecode3` (`coursecode3`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD UNIQUE KEY `notice` (`notice`);

--
-- Indexes for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD UNIQUE KEY `coursecode1` (`coursecode1`),
  ADD UNIQUE KEY `coursecode2` (`coursecode2`),
  ADD UNIQUE KEY `coursecode3` (`coursecode3`),
  ADD UNIQUE KEY `coursecode4` (`coursecode4`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
